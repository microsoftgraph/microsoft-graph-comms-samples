# Description

The resource is responsible for configuring
the Windows Update Agent on the node.
